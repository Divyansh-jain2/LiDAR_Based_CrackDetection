import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
df = pd.read_csv('lidar_data_processed.csv').to_numpy()
# print(df['Time'])
# colNames = ['-0.546','-0.517','-0.488','-0.459','-0.43','-0.401','-0.372','-0.343','-0.314']
# df_required = df.loc[['-0.546','-0.517','-0.488','-0.459','-0.43','-0.401','-0.372','-0.343','-0.314']]
# times = df['Time']

# for col in (colNames):
#     plt.plot(range(len(df_required)), df_required[col], label = f'Angle = {col}')
# plt.legend()
# plt.show()
selected_columns = df[:]
print(selected_columns[:, 4])

# Create a line plot for each column
plt.figure(figsize=(10, 6))  # Adjust the figure size as needed

for column in range(10):
    plt.plot(range(len(selected_columns)), selected_columns[:, column], label=column)

# Add labels and title
plt.xlabel('Time')
plt.ylabel('Values')
plt.title('Line Plot of Columns 19 to 27')
plt.legend(title='Columns', bbox_to_anchor=(1.05, 1), loc='upper left')  # Adjust legend position if needed
plt.tight_layout()

# Show the plot
plt.show()
