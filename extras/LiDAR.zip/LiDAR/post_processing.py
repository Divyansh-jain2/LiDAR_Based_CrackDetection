# import csv
# from datetime import datetime
# import numpy as np

# def process_lidar_data(file_path):
#     # Dictionary to store the distances for each second
#     data_per_second = {}

#     # Read the CSV file
#     with open(file_path, 'r') as file:
#         reader = csv.reader(file)
#         next(reader)  # Skip the header

#         for row in reader:
#             timestamp = row[0]  # Assuming the timestamp is in the first column
#             angle = float(row[1])  # Angle in radians
#             distance = float(row[2])  # Distance in meters
            
#             # Use only the seconds part of the timestamp
#             time_key = timestamp[:-3]  # Trim to second (YYYY-MM-DD HH:MM:SS)

#             # Initialize the list for the second if it doesn't exist
#             if time_key not in data_per_second:
#                 data_per_second[time_key] = []

#             # Only consider angles between -pi/3 and pi/3 (approximately -60 to 60 degrees)
#             # if -np.pi/3 <= angle <= np.pi/3:
#             #     # Append the distance to the appropriate second
#             #     data_per_second[time_key].append(distance)

#     # Calculate averages for each second
#     averages = {}
#     for time_key, distances in data_per_second.items():
#         # We want the average for the first 5 cycles (assuming approximately 5.5 cycles per second)
#         cycles = distances[:5 * (len(distances) // 5)]  # Keep only full cycles
#         if cycles:  # Check if we have any data
#             averages.append(cycles)
#             # averages[time_key] = np.mean(cycles)

#     return averages

# def write_averages_to_csv(averages, output_file_path):
#     # Write the averages to a new CSV file
#     with open(output_file_path, 'w', newline='') as file:
#         writer = csv.writer(file)
#         # Write header
#         writer.writerow(['Time', 'Average Distance (m)'])
        
#         # Write the average distances
#         for time_key, avg_distance in averages.items():
#             writer.writerow([time_key, f'{avg_distance:.3f}'])

# # Example usage
# input_file_path = 'lidar_data.csv'  # Use the absolute path for input
# averages = process_lidar_data(input_file_path)

# # Specify the output file path
# output_file_path = 'lidar_data_processed.csv'  # Change this to your desired output path

# # Write the averages to the output CSV file
# # write_averages_to_csv(averages, output_file_path)

# # Print the average distances for each second
# for time_key, avg_distance in averages.items():
#     print(f'Time: {time_key}, Average Distance: {avg_distance:.3f} m')




# import pandas as pd
# import numpy as np

# df=pd.read_csv(r"rpi_lidar_data_with_timestamp.csv")
# # print(df)
# print(df.columns)
# import pdb;pdb.set_trace()
# df['Time'] = pd.to_datetime(df['Timestamp'])

# # Extract only the time part
# df['Total_Seconds'] = df['Time'].dt.hour * 3600 + df['Time'].dt.minute * 60 + df['Time'].dt.second
# # df['Distance (mm)']=df['Distance (m)']*1000


# # Drop a single column
# # df = df.drop('Distance (m)', axis=1)
# positive_bound=60
# negative_bound=280
# df = df[(df['Angle (degrees)'] <= positive_bound) & (df['Angle (degrees)'] >= negative_bound)]
# import pdb;pdb.set_trace()
# df['Time'] = df['Time'].dt.floor('s')  # Round down to the nearest second
# max_distance = df['Distance (mm)'][np.isfinite(df['Distance (mm)'])].max()

# # Replace infinite values with the maximum distance found
# df['Distance (mm)'].replace([np.inf, -np.inf], max_distance, inplace=True)

# df_avg = df.groupby(['Time', 'Angle (degrees)'])['Distance (mm)'].mean().reset_index()
# df_pivot = df_avg.pivot(index='Time', columns='Angle (degrees)', values='Distance (mm)')
# df_pivot.reset_index(inplace=True)
# cols_to_keep = [df_pivot.columns[0]]  # Keep the first column ('Time')

# # Start from the third column (index 2)
# for i in range(2, len(df_pivot.columns), 5):  # Step by 5 (keep one, skip four)
#     cols_to_keep.append(df_pivot.columns[i])  # Keep the current column

# # Create a new DataFrame with the selected columns
# df_final = df_pivot[cols_to_keep]
# df_final.iloc[:, 1:] = df_final.iloc[:, 1:].diff()
# df_final = df_final.drop(index=0)
# df_final.iloc[:, 1:] = np.trunc(df_final.iloc[:, 1:].values * 1000) / 1000

# df_final.to_csv('lidar_data_processed.csv', index=False)


import pandas as pd
import numpy as np

df = pd.read_csv(r"lidar_data_with_timestamp_high.csv")

print(df.columns)

df['Time'] = pd.to_datetime(df['Timestamp'])

df.drop(columns='Timestamp',axis=1,inplace=True)
df['Total_Seconds'] = df['Time'].dt.hour * 3600 + df['Time'].dt.minute * 60 + df['Time'].dt.second

positive_bound = 80
negative_bound = 270
df = df[(df['Angle (degrees)'] <= positive_bound) | (df['Angle (degrees)'] >= negative_bound)]

df['Time'] = df['Time'].dt.floor('s')  # Round down to the nearest second
max_distance = df['Distance (mm)'][np.isfinite(df['Distance (mm)'])].max()

# Replace infinite values with the maximum distance found
df['Distance (mm)'].replace([np.inf, -np.inf], max_distance, inplace=True)

df_avg = df.groupby(['Time', 'Angle (degrees)'])['Distance (mm)'].mean().reset_index()
df_avg['Angle (degrees)'] = df_avg['Angle (degrees)'].round()
df_avg = df_avg.groupby(['Time', 'Angle (degrees)'])['Distance (mm)'].mean().reset_index()
print(df_avg)
df_avg.to_csv('test.csv', index=False)

df_pivot = df_avg.pivot(index='Time', columns='Angle (degrees)', values='Distance (mm)')

df_pivot = df_pivot.apply(lambda row: row.fillna(method='ffill').fillna(method='bfill'), axis=1)
print(df_pivot)
df_pivot.reset_index(inplace=True)


angle_columns_8_to_90 = [col for col in df_pivot.columns if isinstance(col, (int, float)) and 8 <= col <= 90]
reversed_columns_8_to_90 = angle_columns_8_to_90[::-1]
angle_columns_above_200 = [col for col in df_pivot.columns if isinstance(col, (int, float)) and col > 200]
reversed_columns_above_200 = angle_columns_above_200[::-1]

new_columns_order = (['Time'] +reversed_columns_8_to_90 +[col for col in df_pivot.columns if col not in angle_columns_8_to_90 and col not in angle_columns_above_200 and col != 'Time'] +reversed_columns_above_200
)

df_final= df_pivot[new_columns_order]

df_final.iloc[:, 1:] = df_final.iloc[:, 1:].diff()
df_final.reset_index(drop=True, inplace=True)  # Reset the index
df_final = df_final.drop(index=0)  # Drop the first row
df_final.iloc[:, 1:] = np.trunc(df_final.iloc[:, 1:].values * 1000) / 1000

df_final.to_csv('lidar_data_processed.csv', index=False)






# # Load the data
# df = pd.read_csv("lidar_distance_angle_averages.csv")  # Use the correct file name here
# print("Original DataFrame:")
# print(df)
# print()

# # Convert 'Time' column to datetime if not already done
# df['Time'] = pd.to_datetime(df['Time'])

# # Create a pivot table to reshape the DataFrame
# pivoted_df = df.pivot(index='Time', columns='Angle (rad)', values='Average Distance (mm)')

# # Reset the index to make 'Time' a column again
# pivoted_df.reset_index(inplace=True)

# # Fill NaN values with 0 or any appropriate value
# pivoted_df.fillna(0, inplace=True)

# # Rename the columns to be more descriptive
# pivoted_df.columns.name = None  # Remove the name of the columns
# pivoted_df.columns = [f"Angle_{angle:.3f}" if isinstance(angle, (int, float)) else angle for angle in pivoted_df.columns]

# # Write the pivoted DataFrame to a new CSV file
# pivoted_df.to_csv('lidar_angle_distance_pivoted.csv', index=False)




# # Delete every 3 consecutive columns starting from the 3rd column
# columns_to_delete = []
# for i in range(2, len(pivoted_df.columns), 9):  # Start from the 3rd column (index 2)
#     columns_to_delete.extend(pivoted_df.columns[i:i + 8])  # Get the next 3 columns

# # Drop the identified columns
# pivoted_df.drop(columns=columns_to_delete, inplace=True)
# pivoted_df.iloc[:, 1:] = pivoted_df.iloc[:, 1:].round(2)  # Assuming the first column is 'Time'
# # Set display options for better viewing
# pd.set_option('display.max_rows', None)
# pd.set_option('display.max_columns', None)
# # Print the pivoted DataFrame
# print("Pivoted DataFrame:")
# print(pivoted_df)
# print(len(pivoted_df.columns))
# pivoted_df.to_csv('lidar_data_processed.csv', index=False)

# dataset2=pivoted_df.diff()
# # Apply differencing to all columns except the first one
# dataset2.iloc[:, 1:] = dataset2.iloc[:, 1:].diff()

# # Drop the first row since it will contain NaN values after differencing
# dataset2 = dataset2.dropna()
# dataset2.to_csv('lidar_data_diff.csv', index=False)
# print(dataset2)
